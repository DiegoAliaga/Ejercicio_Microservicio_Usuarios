package cl.inicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiCreacionUsuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
