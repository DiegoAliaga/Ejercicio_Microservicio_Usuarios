package cl;

public class swaggerConfig {

}
